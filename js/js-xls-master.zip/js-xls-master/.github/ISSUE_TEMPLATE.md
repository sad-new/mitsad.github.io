# THIS PROJECT HAS BEEN MERGED INTO js-xlsx

If you have not doneso already, please upgrade! js-xlsx is compatible with the
full js-xls API and has additional features like XLSX support.  The browser code
additionally exports the XLS variable so there is no need to rewrite existing
client code!

Repo: [https://github.com/sheetjs/js-xlsx](https://github.com/sheetjs/js-xlsx)

Node module: [xlsx](https://npm.im/xlsx)

Issues reported here may be missed, and most replies will direct you to upgrade
to js-xlsx first. 
