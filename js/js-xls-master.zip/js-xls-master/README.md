NOTE: this has been merged into [js-xlsx](https://github.com/sheetjs/js-xlsx).

[xlsx module for npm](http://npm.im/xlsx)

Issues should be reported to [xlsx](https://github.com/SheetJS/js-xlsx/issues/)
